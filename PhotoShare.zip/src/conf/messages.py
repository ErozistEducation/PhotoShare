ACCOUNT_EXIST = "Account already exists!"
